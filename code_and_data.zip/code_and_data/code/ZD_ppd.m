clc;clear all;
z=500e-3;                       %探测器的距离（平顶光束旋转点为原点）单位m
z0=0;                        %高斯光束的位置
a = 0;
%a=linspace(-4e-4,4e-4,11);   %角度

p0 = 1;
n=1000;                      %总采样点数
l=2.5e-3;                       %探测器尺寸
r=0.5e-3;                       %平面波轮廓半径
gap=10e-6;                   %探测器间隙宽度
dn=gap/(2*l)*n;
nn=(n-dn)/2;
t = linspace(0,0.001,10000);

lambda=1.064e-6;             %波长
f = 3e8/lambda;             %频率
f_0 = 1e6;                     %频率差
k=2*pi/lambda;               %波数
w0=0.5e-3;                      %束腰

p4 = zeros(1,100);
m=length(t);
p3 = zeros(1,100);
I1=zeros(1,100);
Icos=zeros(1,100);
Isin=zeros(1,100);
zeros(1,100);
I_SIN=zeros(1,100);
% Interference_I=zeros(1000,1000,2000);
uu=1;
%振动项设置
% Display the Zernike function Z(n=5,m=1)
for aa=1:7%4
    bb=(aa-13); 
    A =10^bb;%振动幅度
    for nnn=0.1:0.1:2%差频倍数
    %for nnn=[0.001,0.01]%差频倍数
%     nnn=0;
        L = A*cos(2*pi*nnn*f_0.*t);
        ZD_x = 4*pi.*L/lambda;
        ii=1;
%         for ii=1:100
        %正交解调求相位
        tic
            for tt = 1:100
              gaussian_E = f_Gaussian_beams(w0,z,l,n,n).*exp(2i*pi*f*t(tt+(ii-1)*100)); 
              plane_E=(f_plane_wave(z,z0,l,n,n,a,p0-ZD_x(tt+(ii-1)*100))).*exp(2i*pi*(f+f_0)*t(tt+(ii-1)*100));
%               plane_E1=(f_plane_wave(z,z0,l,n,n,a,0))*exp(2i*pi*(f)*t(tt));%测试
%               Interference_E = plane_E+plane_E1;
              Interference_E = plane_E+gaussian_E;
%               Interference_E=gaussian_E.*conj(plane_E);
%               Interference_E = plane_E+plane_E1;
              Interference_I = real(abs(Interference_E).^2);
            %   Interference_I = abs(Interference_E).^2;
              B3=mat2cell(Interference_I,[nn dn nn],[nn dn nn]);       %将矩阵分解为元胞
              B4=cellfun(@nansum,cellfun(@nansum,B3,'UniformOutput',false));
              I1(tt)=real(B4(1,1)+B4(1,3)+B4(3,1)+B4(3,3));
              Icos(tt)=I1(tt).*cos(2*pi*f_0*t(tt));
              Isin(tt)=I1(tt).*sin(2*pi*f_0*t(tt));
            end 
           toc
           cos1 = sum(Icos);
           sin1 = sum(Isin);
           p4(uu) = -atan(sin1/cos1);           %解调出的相位信息（）
           uu=uu+1;
%         end
%             name_res = ['I_',num2str(nnn*10),num2str(bb)];
%             save(['F:\工作目录\小论文2\数据代码\数据\', name_res],'p4')
    end
    
 end
     save(['F:\工作目录\小论文2\数据代码\数据\', name_res],'p4')
     
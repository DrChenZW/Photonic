%***********************平顶光束产生函数**************************
function plane_E = f_plane_wave(z,z0,R,Nx,Ny,tha,p0)
%z0表示平顶光束旋转点
%Nx，Ny: x,y方向等分割数目
%R表示光缆半径
%tha表示旋转角
%f_1表示频率差
%t表示时间序列
%单位为mm
lamda = 1.064e-6;
[x,y]=meshgrid(linspace(-R,R,Nx),linspace(-R,R,Ny));
D1=(x.^2+y.^2).^(1/2);     %采样圆
%%消除采样圆外值
li=find(D1>=R);
x(li) = nan;
y(li) = nan;

k = 2*pi/lamda;

plane_E = exp(1i*k.*(x.*sin(tha)+(z-z0)*cos(tha))+1i.*p0);

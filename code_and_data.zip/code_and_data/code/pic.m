clc
clear all

load('F:\工作目录\小论文2\数据代码\数据\PDD.mat','PD')
PDD = PD;
load('F:\工作目录\小论文2\数据代码\数据\PDH.mat','PD')
PDH = PD;
load('F:\工作目录\小论文2\数据代码\数据\XZD_0.mat','p4')
PD0 = p4;

rr =  zeros(7,20);


f_0 = 1e6; 
lambda=1.064e-6;  
t = linspace(0,0.001,100);
nnn = 0.1;
A = 10^(7-13);
L = A*cos(2*pi*nnn.*t);
ZD_x = 4*pi.*L/lambda;
% % % 高频数据
% for ii=1:7
%     for jj=1:20
%         cc=(ii-1)*20+jj;
%         rr(ii,jj)=mean(PDH(cc,:)-PD0);
%     end
%      plot(rr(ii,:))
%      hold on
% end
% 
% hold off

% sj = rand(1,1000);
% sj1=sum(sj);r1=sj/(10*sj1);
% sj0 = rand(1,1000);
% sj2=sum(sj0);r2=sj/(10*sj1);
% aa = linspace(0.54680000,0.54680001,1000);
% plot(aa+r1)
% hold on
% bb = linspace(0.55140000,0.55140001,1000);
% plot(bb+r2)
% plot(ZD_x(1:100))

%低频数据
for ii=28:28
    plot(abs(PDD(ii,:)-PDD(25,:)))
    hold on
end
plot(abs(ZD_x-ZD_x(1)))
hold off

% dd = zeros(1,140);
% cc=1;
% PD = zeros(28,100);
% for aa=1:7    
%     for i=[1,10,100,1000]
%     bb=aa-13;
%     name_res = ['F:\工作目录\小论文2\数据代码\数据\新低频\','XZD_',num2str(i),num2str(bb),'.mat'];
% %     cc=i+(aa-1)*20;
%     load(name_res);
%     PD(cc,:)=p4;
%     plot(abs(PD(cc,:)))
%     cc=cc+1;
%     hold on
%     end
% end
% for ii=1:140
%     dd(ii) = var(PD(ii,:));
%     plot(PD(ii,:))
%     hold on
% end
% save('F:\工作目录\小论文2\数据代码\数据\PDD','PD')




% plot(PD)

% plot(A,'--*r')
% hold on
% plot(B,'--+b')
% grid on;
% set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
% xlabel('Aberration size（λ/100-λ）');
% ylabel('Phase/rad');
% % title('球差与慧差对相位的影响')
% legend('spherical','coma');



grid on;

% set(gca,'ytick',0:10:100);
% set(gca,'YScale','log') 
ylabel('phase/rad');
xlabel('time');
% title('算力设置值30')
set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
